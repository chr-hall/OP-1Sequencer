package org.example;

import javax.sound.midi.Sequence;

public class MIDISequence {
    private Sequence MIDISequence;
}
