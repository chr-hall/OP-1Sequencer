package org.example;

import java.util.ArrayList;

public class StepsGrid {
    private ArrayList<Steps> stepsGrid;
    public StepsGrid(ArrayList<Steps> stepsGrid) {
        this.stepsGrid = stepsGrid;
    }

    public ArrayList<Steps> getStepsGrid() {
        return stepsGrid;
    }

    public void setStepsGrid(ArrayList<Steps> stepsGrid) {
        this.stepsGrid = stepsGrid;
    }
}
